
Contents
========================================

.. toctree::

   index
   goals
   support
   building
   api_ref/contents
   cli
   deprecated
   roadmap
   credits
   abi
   packaging
   security
   side_channels
   dev_ref/contents

.. toctree::
   :hidden:

   old_news
